package com.example.payrollsystem;

public class AppData {
    private String data;
    String _id,fname,lname,mname,dob,sex,contact, address, position, stdate,rpd,otpay;
    String pid,empid,sss,pb,ph,totaldeduction,totalsalary,sr,paydate,ot,nwd;
    public AppData()
    {
        this.data = "";
        this._id = "";
        this.fname = "";
        this.lname = "";
        this.mname = "";
        this.dob = "";
        this.sex = "";
        this.contact = "";
        this.address = "";
        this.position = "";
        this.stdate = "";
        this.otpay= "";
        this.rpd = "";
        this.pid= "";
        this.empid="";
        this.sss= "";
        this.pb = "";
        this.ph= "";
        this.sr="";
        this.totalsalary= "";
        this.totaldeduction = "";
        this.paydate= "";
        this.ot= "";
        this.nwd = "";

    }

}
